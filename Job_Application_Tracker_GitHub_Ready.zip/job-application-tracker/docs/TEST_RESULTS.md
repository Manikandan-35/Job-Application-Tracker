# Verification results

Date: 8 October 2026

Command:

```text
python -m unittest discover -s tests -v
```

Result: **14 tests passed**, using isolated temporary SQLite databases.

Verified behaviors:

- Registration, password hashing, login, and session-token rotation.
- Complete application creation, editing, status updates, deletion, and history cleanup.
- Account isolation for viewing, editing, status changes, deletion, and export.
- CSRF rejection, including malformed Unicode tokens; GET cannot sign a user out.
- Authentication redirects and invalid registration rejection.
- Server validation of dates, statuses, types, links, and text lengths.
- Stale-tab changes cannot overwrite or delete a newer version.
- Search, filters, literal search characters, and pagination.
- CSV Unicode/quoting, formula-like cell protection, filtered export, and results beyond page one.
- Fictional sample records are added only to the current user's empty tracker.
- Application changes roll back if the history write fails.
- HTML escaping and parameterized SQL values.
- Stored records survive an application restart.

Browser verification: attempted with Chromium/Playwright. Chromium could not launch because a required socket was blocked by the execution environment. No screenshot or browser-pass claim is included. Visual/mobile behavior should be checked after starting the app locally.
