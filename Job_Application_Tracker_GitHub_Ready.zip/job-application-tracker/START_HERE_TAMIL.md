# Mani — Job Application Tracker

Idhu un second GitHub project. Company-ku apply panna details, interview dates, status, notes ellam ore place-la save pannalam.

## 1. Laptop-la run panna

1. `Job_Application_Tracker_GitHub_Ready.zip` download pannu.
2. ZIP-a right-click → **Extract All** pannu.
3. Extracted `job-application-tracker` folder-a VS Code-la open pannu.
4. Python 3.10+ install aagirukkanum. VS Code-la **Terminal → New Terminal** open pannu.
5. Indha commands-a one by one run pannu:

```powershell
py -3 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe app.py
```

6. Chrome-la **http://127.0.0.1:5001** open pannu.
7. **Create account** click panni name, email, password kuduthu register pannu.
8. Andha email/password-la sign in pannu.
9. **Add application** click panni company, job role, applied date, status save pannu.

Sample-a try panna empty dashboard-la **Try sample applications** click pannalam. Andha companies fictional demo data; real vacancies illa. Nee edit/delete pannalam.

## 2. App-la enna pannalam?

- Company, job role, location, internship/full-time type add pannalam.
- Applied → Screening → Interview → Offer / Rejected / Withdrawn status update pannalam.
- Interview date/time, follow-up date, job link, notes save pannalam.
- Dashboard-la totals, status chart, upcoming interviews, overdue follow-ups paarkalam.
- Company/role/location search panni status/type filter use pannalam.
- **Download CSV** click panni records download pannalam.

Interview time **IST**-la enter pannu. Follow-up dashboard-la theriyum; SMS/email automatic-a anuppadhu.

Stop panna terminal-la `Ctrl+C` press pannu. Next time same project terminal-la `.venv\Scripts\python.exe app.py` run pannina saved details thirumba varum.

## 3. GitHub-la upload panna

Indha project-ku **thani repository** create pannu. Bank project folder-oda mix panna vendam.

- Repository name: `job-application-tracker`
- Description: `A Flask and SQLite web app to track job applications, interviews, follow-ups, and status history.`

1. GitHub-la new repository create pannu.
2. Extract panna `job-application-tracker` folder-a open pannu.
3. GitHub repository-la **Add file → Upload files** click pannu.
4. Folder-kulla irukkura files-um `templates`, `static`, `tests`, `docs` folders-um upload area-kku drag pannu.
5. Commit message-la `Add JobTrack application tracker` type panni **Commit changes** click pannu.
6. Code page-la `app.py`, `README.md`, `templates`, `static` ellam theriyudha check pannu.

ZIP mattum upload pannina code ZIP-kulla irukkum. Extract panna contents-a upload pannu. Subfolders-kulla irukkura files-a veliya move panna vendam.

Run pannadhukku appuram create aagura `.venv`, `instance`, database files-a upload panna vendam.

## 4. Project details engay irukku?

- `README.md`: full setup and features.
- `PROJECT_DETAILS.md`: objective, modules, architecture, database, future scope.
- `INTERVIEW_EXPLANATION.md`: interview-la explain panna short answers.

GitHub-la upload pannina code store aagum. App-a laptop-la run panna above commands use pannu.
