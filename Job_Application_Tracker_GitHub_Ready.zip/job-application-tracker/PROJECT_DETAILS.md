# JobTrack — Project Details

**Title:** Job Application Tracking and Interview Management System

**Type:** Academic full-stack web application

## Problem statement

Students and job seekers often store application details in separate notes, emails, and spreadsheets. This makes it difficult to track company names, job roles, application stages, interview schedules, and follow-up dates consistently.

## Objective

Provide a personal dashboard to organize job applications, record interview and follow-up dates, review progress, and export records.

## Implemented modules

| Module | Functions |
| --- | --- |
| User authentication | Register, validate credentials, sign in, sign out, maintain separate accounts. |
| Application management | Create, read, update, and delete job applications. |
| Status pipeline | Applied, Screening, Interview, Offer, Rejected, Withdrawn. |
| Interview and follow-up management | Save dates and show upcoming interviews and due/overdue follow-ups. |
| Dashboard | Counts, status distribution, recent applications, next steps. |
| Search and filtering | Search company/role/location, filter status/job type, paginate results. |
| Reporting | Export matching applications to CSV. |
| Application history | Record creation, edits, and status changes. |

## Technology

| Layer | Technology |
| --- | --- |
| Front end | HTML, responsive CSS, JavaScript |
| Templates | Jinja |
| Back end | Python, Flask |
| Database | SQLite |
| Password handling | Werkzeug password hashing |
| Export | Python CSV module |
| Verification | Python unittest; Playwright browser run attempted (environment-blocked) |

## Architecture

The browser sends requests to Flask. Flask validates forms, checks the signed-in account and CSRF token, and reads/writes SQLite records. Jinja renders HTML responses. JavaScript handles delete confirmation. CSV export uses the same account and filters as the application list.

## Database relationships

```mermaid
erDiagram
    USERS ||--o{ APPLICATIONS : owns
    APPLICATIONS ||--o{ APPLICATION_EVENTS : records
    USERS {
        int id PK
        string name
        string email UK
        string password_hash
    }
    APPLICATIONS {
        int id PK
        int user_id FK
        string company
        string role
        string status
        date applied_on
        datetime interview_at
        date follow_up_on
        int version
    }
    APPLICATION_EVENTS {
        int id PK
        int application_id FK
        string description
        datetime occurred_at
    }
```

SQLite stores dates/timestamps as ISO-format TEXT. Foreign keys link an application to its owner and history to its application. Deleting an application also deletes its history. Indexes support per-user listing and stage filtering.

## Main workflow

Register and sign in. Add a company and role with an applied date. Update the application stage as it progresses. Record interview/follow-up dates when known. Review the dashboard and export records when needed.

## Data rules

- Each account can access only its own records, including history and CSV exports.
- The application date must be today or earlier.
- Interview and follow-up dates cannot precede the application date.
- Interview times are entered and displayed in IST.
- Status and job type must come from the provided lists.
- Posting links accept only complete HTTP/HTTPS URLs.
- A stale browser tab cannot overwrite or delete a newer version of an application.
- Each mutation and its history entry succeed together or roll back together.

## Development verification

All **14 integration tests passed** on 8 October 2026. The checks exercised registration/login, CRUD and history, user isolation, CSRF, validation, stale-tab conflicts, transactional rollback, CSV handling, search/filter pagination, sample data, HTML escaping, and persistence after restart.

An automated Chromium run was attempted but could not launch because the execution environment blocked a required socket. Desktop/mobile visual verification is therefore pending; no browser-pass result is claimed. See `docs/TEST_RESULTS.md`.

## Scope and future improvements

This implementation uses manually entered applications. Follow-up dates appear on the dashboard; email/SMS and background notifications are future improvements. It does not apply to companies automatically, scrape job websites, or predict hiring success.

Other possible extensions: multiple interview rounds, document attachments, a calendar view, and deployed multi-device access.

This project was generated with AI assistance for learning and review. The fictional examples are demonstration data. No hiring outcomes or performance metrics are claimed.
