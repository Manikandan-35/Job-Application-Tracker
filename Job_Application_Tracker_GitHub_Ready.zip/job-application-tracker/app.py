"""JobTrack: a local, account-scoped job application tracker."""
from contextlib import contextmanager
from datetime import date, datetime, timedelta
from functools import wraps
from io import StringIO
from pathlib import Path
from urllib.parse import urlsplit
from zoneinfo import ZoneInfo
import argparse
import csv
import hmac
import os
import re
import secrets
import sqlite3

from flask import Flask, Response, abort, flash, g, redirect, render_template, request, session, url_for
from werkzeug.exceptions import HTTPException
from werkzeug.security import check_password_hash, generate_password_hash

ROOT = Path(__file__).resolve().parent
TIMEZONE = ZoneInfo("Asia/Kolkata")
STATUSES = ("Applied", "Screening", "Interview", "Offer", "Rejected", "Withdrawn")
ACTIVE_STATUSES = STATUSES[:3]
JOB_TYPES = ("Internship", "Full-time", "Part-time", "Contract")
FIELDS = ("company", "role", "location", "job_type", "status", "applied_on",
          "interview_at", "follow_up_on", "job_url", "notes")
EMAIL_PATTERN = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")


def now():
    return datetime.now(TIMEZONE)


def timestamp():
    return now().isoformat(timespec="seconds")


def get_db():
    if "db" not in g:
        from flask import current_app
        path = Path(current_app.config["DATABASE"])
        path.parent.mkdir(parents=True, exist_ok=True)
        db = sqlite3.connect(path, isolation_level=None, timeout=10)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        db.execute("PRAGMA busy_timeout=10000")
        g.db = db
    return g.db


@contextmanager
def transaction():
    db = get_db()
    db.execute("BEGIN IMMEDIATE")
    try:
        yield db
        db.commit()
    except BaseException:
        db.rollback()
        raise


def csrf_token():
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_urlsafe(32)
    return session["csrf_token"]


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if g.user is None:
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


def account_error(name, email, password):
    if not 2 <= len(name) <= 80 or any(ord(c) < 32 for c in name):
        return "Enter a name between 2 and 80 characters."
    if len(email) > 254 or not EMAIL_PATTERN.fullmatch(email):
        return "Enter a valid email address."
    if not 8 <= len(password) <= 128:
        return "Use a password between 8 and 128 characters."
    return None


def parse_day(value, label, optional=False):
    if not value and optional:
        return None
    try:
        result = date.fromisoformat(value)
        if result.isoformat() != value:
            raise ValueError
    except (ValueError, TypeError):
        raise ValueError(f"Enter a valid {label}.") from None
    return result


def application_values(form):
    values = {field: form.get(field, "").strip() for field in FIELDS}
    for field, minimum, maximum in [("company", 1, 120), ("role", 1, 120), ("location", 0, 120)]:
        if not minimum <= len(values[field]) <= maximum or any(ord(c) < 32 for c in values[field]):
            raise ValueError(f"{field.replace('_', ' ').title()} must be {minimum}–{maximum} characters.")
    if values["job_type"] not in JOB_TYPES:
        raise ValueError("Choose an available job type.")
    if values["status"] not in STATUSES:
        raise ValueError("Choose an available status.")
    applied = parse_day(values["applied_on"], "application date")
    if applied > now().date():
        raise ValueError("The application date cannot be in the future.")
    follow_up = parse_day(values["follow_up_on"], "follow-up date", optional=True)
    if follow_up and follow_up < applied:
        raise ValueError("The follow-up date cannot be before the application date.")
    if values["interview_at"]:
        try:
            interview = datetime.fromisoformat(values["interview_at"])
            if interview.strftime("%Y-%m-%dT%H:%M") != values["interview_at"] or interview.tzinfo:
                raise ValueError
        except ValueError:
            raise ValueError("Enter a valid interview date and time.") from None
        if interview.date() < applied:
            raise ValueError("The interview cannot be before the application date.")
    if values["job_url"]:
        try:
            link = urlsplit(values["job_url"])
            valid = (link.scheme in {"http", "https"} and bool(link.hostname)
                     and link.username is None and link.password is None)
            _ = link.port
        except ValueError:
            valid = False
        if (not valid or len(values["job_url"]) > 1000
                or any(c.isspace() or ord(c) < 32 for c in values["job_url"])):
            raise ValueError("Use a complete http:// or https:// job link without spaces.")
    if len(values["notes"]) > 4000 or "\x00" in values["notes"]:
        raise ValueError("Notes must be at most 4,000 characters and cannot contain null characters.")
    for field in ("interview_at", "follow_up_on", "job_url"):
        values[field] = values[field] or None
    return values


def application_or_404(application_id):
    row = get_db().execute("SELECT * FROM applications WHERE id=? AND user_id=?",
                           (application_id, g.user["id"])).fetchone()
    if row is None:
        abort(404, description="This application was not found in your account.")
    return dict(row)


def submitted_version():
    try:
        version = int(request.form.get("version", ""))
        if version < 1:
            raise ValueError
    except (ValueError, TypeError):
        abort(400, description="Reload the application before changing it.")
    return version


def event(db, application_id, description):
    db.execute("INSERT INTO application_events (application_id, description, occurred_at) VALUES (?, ?, ?)",
               (application_id, description, timestamp()))


def filters():
    selected = {key: request.args.get(key, "").strip() for key in ("q", "status", "job_type")}
    if len(selected["q"]) > 120:
        abort(400, description="Search must be at most 120 characters.")
    if selected["status"] and selected["status"] not in STATUSES:
        abort(400, description="Invalid status filter.")
    if selected["job_type"] and selected["job_type"] not in JOB_TYPES:
        abort(400, description="Invalid job type filter.")
    where, params = ["user_id=?"], [g.user["id"]]
    if selected["q"]:
        where.append("(instr(lower(company), lower(?))>0 OR instr(lower(role), lower(?))>0 OR instr(lower(location), lower(?))>0)")
        params.extend([selected["q"]] * 3)
    for key in ("status", "job_type"):
        if selected[key]:
            where.append(f"{key}=?")
            params.append(selected[key])
    return selected, " AND ".join(where), params


def csv_cell(value):
    text = "" if value is None else str(value)
    # Quote spreadsheet formulas as text, including formulas preceded by whitespace.
    if text.lstrip().startswith(("=", "+", "-", "@")) or text.startswith(("\t", "\r", "\n")):
        return "'" + text
    return text


def create_app(test_config=None):
    app = Flask(__name__, instance_path=str(ROOT / "instance"))
    app.config.update(
        DATABASE=os.getenv("DATABASE_PATH", str(ROOT / "instance" / "jobtrack.db")),
        SECRET_KEY=os.getenv("SECRET_KEY"), MAX_CONTENT_LENGTH=64 * 1024,
        SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=os.getenv("COOKIE_SECURE", "0") == "1",
        PERMANENT_SESSION_LIFETIME=timedelta(hours=8),
    )
    if test_config:
        app.config.update(test_config)
    if not app.config["SECRET_KEY"]:
        secret = Path(app.instance_path) / ".secret_key"
        secret.parent.mkdir(parents=True, exist_ok=True)
        try:
            with secret.open("x", encoding="utf-8") as handle:
                handle.write(secrets.token_hex(32))
            secret.chmod(0o600)
        except FileExistsError:
            pass
        app.config["SECRET_KEY"] = secret.read_text(encoding="utf-8").strip()
        if len(app.config["SECRET_KEY"]) < 32:
            raise RuntimeError("The local session key is incomplete. Set SECRET_KEY or regenerate instance/.secret_key.")

    @app.teardown_appcontext
    def close_db(_error):
        db = g.pop("db", None)
        if db is not None:
            db.close()

    with app.app_context():
        get_db().executescript((ROOT / "schema.sql").read_text(encoding="utf-8"))

    @app.before_request
    def load_user_and_check_csrf():
        g.user = None
        if session.get("user_id") is not None:
            row = get_db().execute("SELECT id, name, email FROM users WHERE id=?", (session["user_id"],)).fetchone()
            if row:
                g.user = dict(row)
            else:
                session.clear()
        if request.method in {"POST", "PUT", "PATCH", "DELETE"}:
            expected, supplied = session.get("csrf_token", ""), request.form.get("csrf_token", "")
            if not expected or not hmac.compare_digest(expected.encode(), supplied.encode()):
                abort(400, description="This form has expired. Reload the page and try again.")

    @app.context_processor
    def helpers():
        return {"current_user": g.get("user"), "csrf_token": csrf_token, "statuses": STATUSES,
                "job_types": JOB_TYPES, "today": now().date().isoformat()}

    @app.template_filter("pretty_date")
    def pretty_date(value):
        return date.fromisoformat(value).strftime("%d %b %Y") if value else "Not set"

    @app.template_filter("pretty_time")
    def pretty_time(value):
        return datetime.fromisoformat(value).strftime("%d %b %Y, %I:%M %p") + " IST" if value else "Not set"

    @app.template_filter("status_class")
    def status_class(value):
        return value.lower().replace(" ", "-")

    @app.after_request
    def headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "same-origin"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
            "frame-ancestors 'none'; form-action 'self'; base-uri 'self'")
        if g.get("user"):
            response.headers["Cache-Control"] = "no-store"
        return response

    @app.errorhandler(HTTPException)
    def http_error(error):
        return render_template("error.html", error=error), error.code

    @app.get("/")
    def home():
        if g.user:
            return redirect(url_for("dashboard"))
        return render_template("home.html")

    @app.route("/register", methods=["GET", "POST"])
    def register():
        error = None
        if request.method == "POST":
            name = request.form.get("name", "").strip()
            email = request.form.get("email", "").strip().lower()
            password = request.form.get("password", "")
            error = account_error(name, email, password)
            if not error and password != request.form.get("confirm_password", ""):
                error = "The passwords do not match."
            if not error:
                try:
                    with transaction() as db:
                        db.execute("INSERT INTO users (name, email, password_hash, created_at) VALUES (?, ?, ?, ?)",
                                   (name, email, generate_password_hash(password), timestamp()))
                except sqlite3.IntegrityError:
                    error = "An account already exists for this email address."
                else:
                    flash("Account created. Sign in to start your tracker.", "success")
                    return redirect(url_for("login"), code=303)
        return render_template("auth.html", mode="register", values=request.form, error=error), 400 if error else 200

    @app.route("/login", methods=["GET", "POST"])
    def login():
        error = None
        if request.method == "POST":
            email, password = request.form.get("email", "").strip().lower(), request.form.get("password", "")
            user = get_db().execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
            if not user or len(password) > 128 or not check_password_hash(user["password_hash"], password):
                error = "The email address or password is incorrect."
            else:
                session.clear()
                session["user_id"] = user["id"]
                session.permanent = True
                csrf_token()
                return redirect(url_for("dashboard"), code=303)
        return render_template("auth.html", mode="login", values=request.form, error=error), 400 if error else 200

    @app.post("/logout")
    @login_required
    def logout():
        session.clear()
        flash("You have signed out.", "success")
        return redirect(url_for("home"), code=303)

    @app.get("/dashboard")
    @login_required
    def dashboard():
        db, user_id = get_db(), g.user["id"]
        counts = {status: 0 for status in STATUSES}
        counts.update({r["status"]: r["n"] for r in db.execute(
            "SELECT status, COUNT(*) n FROM applications WHERE user_id=? GROUP BY status", (user_id,))})
        total = sum(counts.values())
        recent = db.execute("SELECT * FROM applications WHERE user_id=? ORDER BY created_at DESC, id DESC LIMIT 5",
                            (user_id,)).fetchall()
        interview_count = db.execute("""SELECT COUNT(*) FROM applications WHERE user_id=?
            AND status IN ('Applied','Screening','Interview') AND interview_at>=?""",
            (user_id, now().strftime("%Y-%m-%dT%H:%M"))).fetchone()[0]
        interviews = db.execute("""SELECT * FROM applications WHERE user_id=?
            AND status IN ('Applied','Screening','Interview') AND interview_at>=?
            ORDER BY interview_at, id LIMIT 4""", (user_id, now().strftime("%Y-%m-%dT%H:%M"))).fetchall()
        follow_ups = db.execute("""SELECT * FROM applications WHERE user_id=? AND follow_up_on IS NOT NULL
            AND status IN ('Applied','Screening','Interview') ORDER BY follow_up_on, id LIMIT 4""",
            (user_id,)).fetchall()
        return render_template("dashboard.html", counts=counts, total=total, recent=recent,
                               active=sum(counts[s] for s in ACTIVE_STATUSES), interviews=interviews,
                               interview_count=interview_count, follow_ups=follow_ups)

    @app.get("/applications")
    @login_required
    def applications():
        selected, where, params = filters()
        try:
            page = int(request.args.get("page", "1"))
            if page < 1:
                raise ValueError
        except ValueError:
            abort(400, description="Invalid page number.")
        total = get_db().execute("SELECT COUNT(*) FROM applications WHERE " + where, params).fetchone()[0]
        pages = max(1, (total + 11) // 12)
        page = min(page, pages)
        rows = get_db().execute("SELECT * FROM applications WHERE " + where +
                                " ORDER BY applied_on DESC, id DESC LIMIT 12 OFFSET ?",
                                [*params, (page - 1) * 12]).fetchall()
        return render_template("applications.html", applications=rows, filters=selected,
                               total=total, page=page, pages=pages)

    def form_page(existing=None, error=None, status=200):
        values = dict(request.form) if request.method == "POST" else dict(existing or {})
        for key, value in {"applied_on": now().date().isoformat(), "status": "Applied", "job_type": "Internship"}.items():
            values.setdefault(key, value)
        return render_template("application_form.html", values=values, existing=existing, error=error), status

    @app.route("/applications/new", methods=["GET", "POST"])
    @login_required
    def new_application():
        if request.method == "POST":
            try:
                values = application_values(request.form)
            except ValueError as error:
                return form_page(error=str(error), status=400)
            with transaction() as db:
                row = db.execute("INSERT INTO applications (user_id, " + ", ".join(FIELDS) +
                    ", created_at, updated_at) VALUES (" + ",".join(["?"] * (len(FIELDS) + 3)) + ")",
                    (g.user["id"], *(values[k] for k in FIELDS), timestamp(), timestamp()))
                application_id = row.lastrowid
                event(db, application_id, f"Application added · {values['status']}")
            flash("Application added. Your next opportunity is on the board.", "success")
            return redirect(url_for("detail", application_id=application_id), code=303)
        return form_page()

    @app.get("/applications/<int:application_id>")
    @login_required
    def detail(application_id):
        application = application_or_404(application_id)
        history = get_db().execute("SELECT * FROM application_events WHERE application_id=? ORDER BY id DESC",
                                   (application_id,)).fetchall()
        return render_template("detail.html", application=application, history=history)

    @app.route("/applications/<int:application_id>/edit", methods=["GET", "POST"])
    @login_required
    def edit(application_id):
        existing = application_or_404(application_id)
        if request.method == "POST":
            try:
                values = application_values(request.form)
            except ValueError as error:
                return form_page(existing, str(error), 400)
            version = submitted_version()
            with transaction() as db:
                updated = db.execute("UPDATE applications SET " + ", ".join(f"{k}=?" for k in FIELDS) +
                    ", updated_at=?, version=version+1, is_sample=0 WHERE id=? AND user_id=? AND version=?",
                    (*(values[k] for k in FIELDS), timestamp(), application_id, g.user["id"], version))
                if updated.rowcount != 1:
                    abort(409, description="This application changed in another tab. Reload it before saving.")
                event(db, application_id, f"Status changed: {existing['status']} → {values['status']}" if
                      existing["status"] != values["status"] else "Application details updated")
            flash("Application updated.", "success")
            return redirect(url_for("detail", application_id=application_id), code=303)
        return form_page(existing)

    @app.post("/applications/<int:application_id>/status")
    @login_required
    def change_status(application_id):
        application_or_404(application_id)
        status, version = request.form.get("status", ""), submitted_version()
        if status not in STATUSES:
            abort(400, description="Choose an available status.")
        with transaction() as db:
            existing = application_or_404(application_id)
            updated = db.execute("""UPDATE applications SET status=?, updated_at=?, version=version+1
                WHERE id=? AND user_id=? AND version=?""", (status, timestamp(), application_id, g.user["id"], version))
            if updated.rowcount != 1:
                abort(409, description="This application changed in another tab. Reload it before saving.")
            if status != existing["status"]:
                event(db, application_id, f"Status changed: {existing['status']} → {status}")
        flash("Status saved.", "success")
        return redirect(url_for("detail", application_id=application_id), code=303)

    @app.post("/applications/<int:application_id>/delete")
    @login_required
    def delete(application_id):
        application_or_404(application_id)
        version = submitted_version()
        with transaction() as db:
            deleted = db.execute("DELETE FROM applications WHERE id=? AND user_id=? AND version=?",
                                 (application_id, g.user["id"], version))
            if deleted.rowcount != 1:
                abort(409, description="This application changed in another tab. Reload it before deleting.")
        flash("Application deleted.", "success")
        return redirect(url_for("applications"), code=303)

    @app.get("/applications/export.csv")
    @login_required
    def export():
        _selected, where, params = filters()
        rows = get_db().execute("SELECT * FROM applications WHERE " + where +
                                " ORDER BY applied_on DESC, id DESC", params).fetchall()
        output = StringIO(newline="")
        writer = csv.writer(output)
        writer.writerow(["Company", "Role", "Location", "Job type", "Status", "Applied on",
                         "Interview (IST)", "Follow-up on", "Job URL", "Notes"])
        for row in rows:
            writer.writerow([csv_cell(row[k]) for k in FIELDS])
        return Response("\ufeff" + output.getvalue(), mimetype="text/csv",
                        headers={"Content-Disposition": 'attachment; filename="job-applications.csv"'})

    @app.post("/sample-data")
    @login_required
    def sample_data():
        today = now().date()
        examples = [
            ("Harbor Labs", "Full Stack Intern", "Remote", "Applied", 2, None, today + timedelta(days=3)),
            ("Maple Systems", "Python Developer", "Chennai", "Screening", 7, None, today - timedelta(days=1)),
            ("Orbit Studio", "Frontend Intern", "Coimbatore", "Interview", 9,
             (now() + timedelta(days=2)).replace(hour=10, minute=30).strftime("%Y-%m-%dT%H:%M"), None),
            ("Cedar Analytics", "Data Analyst Intern", "Remote", "Offer", 14, None, None),
            ("Bright Path Tech", "Software Intern", "Trichy", "Rejected", 18, None, None),
        ]
        with transaction() as db:
            if db.execute("SELECT 1 FROM applications WHERE user_id=? LIMIT 1", (g.user["id"],)).fetchone():
                abort(409, description="Sample applications can only be added to an empty tracker.")
            for company, role, location, status, days, interview, follow_up in examples:
                row = db.execute("""INSERT INTO applications (user_id, company, role, location, job_type,
                    status, applied_on, interview_at, follow_up_on, notes, is_sample, created_at, updated_at)
                    VALUES (?, ?, ?, ?, 'Internship', ?, ?, ?, ?, ?, 1, ?, ?)""",
                    (g.user["id"], company, role, location, status, (today - timedelta(days=days)).isoformat(),
                     interview, follow_up.isoformat() if follow_up else None,
                     "Fictional sample application for trying JobTrack. Replace it with your own details.",
                     timestamp(), timestamp()))
                event(db, row.lastrowid, f"Fictional sample added · {status}")
        flash("Five fictional sample applications added. You can edit or delete them.", "success")
        return redirect(url_for("dashboard"), code=303)

    return app


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=int(os.getenv("PORT", "5001")))
    args = parser.parse_args()
    if not 1 <= args.port <= 65535:
        parser.error("Port must be between 1 and 65535.")
    create_app().run(host="127.0.0.1", port=args.port, debug=False)
