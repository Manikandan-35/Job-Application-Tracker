CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT COLLATE NOCASE NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS applications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    company TEXT NOT NULL,
    role TEXT NOT NULL,
    location TEXT NOT NULL DEFAULT '',
    job_type TEXT NOT NULL CHECK (job_type IN ('Internship','Full-time','Part-time','Contract')),
    status TEXT NOT NULL DEFAULT 'Applied' CHECK (status IN ('Applied','Screening','Interview','Offer','Rejected','Withdrawn')),
    applied_on TEXT NOT NULL,
    interview_at TEXT,
    follow_up_on TEXT,
    job_url TEXT,
    notes TEXT NOT NULL DEFAULT '',
    is_sample INTEGER NOT NULL DEFAULT 0 CHECK (is_sample IN (0,1)),
    version INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS applications_owner_date ON applications(user_id, applied_on DESC, id DESC);
CREATE INDEX IF NOT EXISTS applications_owner_status ON applications(user_id, status);

CREATE TABLE IF NOT EXISTS application_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    application_id INTEGER NOT NULL REFERENCES applications(id) ON DELETE CASCADE,
    description TEXT NOT NULL,
    occurred_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS events_application ON application_events(application_id, id DESC);
