"""Behavioral integration checks with isolated SQLite databases."""
from datetime import datetime
from io import StringIO
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
import csv
import unittest

import app as tracker
from werkzeug.security import check_password_hash


class TrackerTests(unittest.TestCase):
    def setUp(self):
        self.directory = TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.clock = patch.object(tracker, "now", return_value=datetime(2026, 10, 8, 10, 0, tzinfo=tracker.TIMEZONE))
        self.clock.start()
        self.addCleanup(self.clock.stop)
        self.config = {"TESTING": True, "SECRET_KEY": "isolated-tests-only",
                       "DATABASE": str(Path(self.directory.name) / "test.db")}
        self.app = tracker.create_app(self.config)
        self.client = self.app.test_client()

    def token(self, client=None):
        client = client or self.client
        client.get("/login")
        with client.session_transaction() as session:
            return session["csrf_token"]

    def post(self, path, values=None, client=None):
        client = client or self.client
        return client.post(path, data={"csrf_token": self.token(client), **(values or {})})

    def login(self, email="student@example.com", client=None):
        client = client or self.client
        response = self.post("/register", {"name": "Demo Student", "email": email,
                            "password": "Good-password-12", "confirm_password": "Good-password-12"}, client)
        self.assertEqual(response.status_code, 303)
        response = self.post("/login", {"email": email, "password": "Good-password-12"}, client)
        self.assertEqual(response.status_code, 303)
        return client

    def values(self, **changes):
        result = {"company": "Example Systems", "role": "Python Intern", "location": "Chennai",
                  "job_type": "Internship", "status": "Applied", "applied_on": "2026-10-01",
                  "interview_at": "", "follow_up_on": "2026-10-09", "job_url": "https://example.com/jobs/1",
                  "notes": "Prepare Python and SQL."}
        result.update(changes)
        return result

    def create(self, **changes):
        response = self.post("/applications/new", self.values(**changes))
        self.assertEqual(response.status_code, 303, response.data.decode())
        return int(response.location.rsplit("/", 1)[-1])

    def query(self, sql, params=()):
        with self.app.app_context():
            return [dict(r) for r in tracker.get_db().execute(sql, params).fetchall()]

    def test_registration_login_password_hash_and_session_rotation(self):
        before = self.token()
        self.login()
        user = self.query("SELECT * FROM users")[0]
        self.assertNotEqual(user["password_hash"], "Good-password-12")
        self.assertTrue(check_password_hash(user["password_hash"], "Good-password-12"))
        self.assertNotEqual(before, self.token())
        self.assertEqual(self.client.get("/dashboard").status_code, 200)
        duplicate = self.post("/register", {"name": "Another", "email": "STUDENT@EXAMPLE.COM",
            "password": "Good-password-12", "confirm_password": "Good-password-12"})
        self.assertEqual(duplicate.status_code, 400)
        self.assertEqual(len(self.query("SELECT * FROM users")), 1)
        self.assertEqual(self.post("/login", {"email": "student@example.com", "password": "wrong"}).status_code, 400)

    def test_customer_journey_and_history_cascade(self):
        self.login()
        application_id = self.create()
        response = self.client.get(f"/applications/{application_id}")
        self.assertIn(b"Example Systems", response.data)
        self.assertEqual(response.status_code, 200)
        edit = self.post(f"/applications/{application_id}/edit", self.values(
            status="Interview", interview_at="2026-10-10T14:30", version="1", notes="Practice joins.\nReview projects."))
        self.assertEqual(edit.status_code, 303)
        self.assertIn(b"Status changed: Applied", self.client.get(f"/applications/{application_id}").data)
        status = self.post(f"/applications/{application_id}/status", {"status": "Offer", "version": "2"})
        self.assertEqual(status.status_code, 303)
        row = self.query("SELECT * FROM applications")[0]
        self.assertEqual((row["status"], row["version"]), ("Offer", 3))
        self.assertEqual(len(self.query("SELECT * FROM application_events")), 3)
        deleted = self.post(f"/applications/{application_id}/delete", {"version": "3"})
        self.assertEqual(deleted.status_code, 303)
        self.assertEqual(self.query("SELECT * FROM applications"), [])
        self.assertEqual(self.query("SELECT * FROM application_events"), [])
        self.assertEqual(self.client.get(f"/applications/{application_id}").status_code, 404)

    def test_account_isolation_for_every_application_operation(self):
        self.login()
        application_id = self.create(company="Private Student Company")
        other = self.login("other@example.com", self.app.test_client())
        for path in [f"/applications/{application_id}", f"/applications/{application_id}/edit"]:
            self.assertEqual(other.get(path).status_code, 404)
        for path, values in [(f"/applications/{application_id}/edit", self.values(version="1")),
            (f"/applications/{application_id}/status", {"version": "1", "status": "Offer"}),
            (f"/applications/{application_id}/delete", {"version": "1"})]:
            self.assertEqual(self.post(path, values, other).status_code, 404)
        for path in ["/applications", "/dashboard", "/applications/export.csv"]:
            self.assertNotIn(b"Private Student Company", other.get(path).data)
        self.assertEqual(self.query("SELECT * FROM applications")[0]["status"], "Applied")

    def test_csrf_missing_unicode_invalid_and_get_logout(self):
        self.login()
        self.assertEqual(self.client.post("/applications/new", data=self.values()).status_code, 400)
        invalid = self.client.post("/applications/new", data={**self.values(), "csrf_token": "தமிழ்"})
        self.assertEqual(invalid.status_code, 400)
        self.assertEqual(self.client.get("/logout").status_code, 405)
        self.assertEqual(self.query("SELECT * FROM applications"), [])
        self.assertEqual(self.post("/logout").status_code, 303)
        self.assertEqual(self.client.get("/dashboard").status_code, 302)

    def test_unauthed_routes_redirect_and_registration_validation(self):
        for path in ["/dashboard", "/applications", "/applications/new", "/applications/export.csv"]:
            response = self.client.get(path)
            self.assertEqual(response.status_code, 302)
            self.assertTrue(response.location.endswith("/login"))
        for values in [{"name": "x", "email": "bad", "password": "x", "confirm_password": "x"},
                       {"name": "Student", "email": "a@example.com", "password": "Password-12", "confirm_password": "other"}]:
            self.assertEqual(self.post("/register", values).status_code, 400)
        self.assertEqual(self.query("SELECT * FROM users"), [])

    def test_server_validation_rejects_bad_dates_statuses_links_and_lengths(self):
        self.login()
        for change in [dict(company=""), dict(role="x" * 121), dict(status="Admin"), dict(job_type="Unknown"),
            dict(applied_on="2026-10-09"), dict(applied_on="2026-02-30"), dict(applied_on="20261001"),
            dict(follow_up_on="2026-09-30"), dict(interview_at="2026-09-30T10:00"),
            dict(interview_at="2026-10-10T10:00+05:30"), dict(job_url="javascript:alert(1)"),
            dict(job_url="https://user:password@example.com/"), dict(job_url="https://example.com:bad"),
            dict(job_url="https://example.com/a b"), dict(notes="x" * 4001)]:
            with self.subTest(change=change):
                self.assertEqual(self.post("/applications/new", self.values(**change)).status_code, 400)
        self.assertEqual(self.query("SELECT * FROM applications"), [])

    def test_stale_edits_status_and_delete_do_not_overwrite_new_changes(self):
        self.login()
        application_id = self.create()
        self.assertEqual(self.post(f"/applications/{application_id}/status", {"status": "Interview", "version": "1"}).status_code, 303)
        for path, values in [("edit", self.values(company="Stale Change", version="1")),
                             ("status", {"status": "Rejected", "version": "1"}), ("delete", {"version": "1"})]:
            self.assertEqual(self.post(f"/applications/{application_id}/{path}", values).status_code, 409)
        row = self.query("SELECT * FROM applications")[0]
        self.assertEqual((row["company"], row["status"], row["version"]), ("Example Systems", "Interview", 2))
        self.assertEqual(len(self.query("SELECT * FROM application_events")), 2)
        self.assertEqual(self.post(f"/applications/{application_id}/status", {"status": "Offer", "version": "bad"}).status_code, 400)

    def test_filters_literal_search_and_pagination(self):
        self.login()
        for index in range(13):
            self.create(company=f"Paged Company {index:02d}", status="Interview" if index < 4 else "Applied")
        self.create(company="100%_Systems", location="Remote", job_type="Full-time")
        all_rows = self.client.get("/applications")
        self.assertIn(b"Page 1 of 2", all_rows.data)
        self.assertIn(b"Paged Company 00", self.client.get("/applications?page=2").data)
        filtered = self.client.get("/applications?status=Interview")
        self.assertIn(b"4 applications matching", filtered.data)
        self.assertNotIn(b"100%_Systems", filtered.data)
        literal = self.client.get("/applications?q=%25_")
        self.assertIn(b"100%_Systems", literal.data)
        self.assertNotIn(b"Paged Company", literal.data)
        self.assertEqual(self.client.get("/applications?q=%27%20OR%201%3D1--").status_code, 200)
        for query in ["status=Administrator", "page=0", "page=no", "job_type=Unknown"]:
            self.assertEqual(self.client.get("/applications?" + query).status_code, 400)
        self.assertEqual(len(self.query("SELECT * FROM applications")), 14)

    def test_csv_unicode_quoting_formula_safety_and_filtered_export(self):
        self.login()
        self.create(company='தமிழ், "Systems"', role="=1+1", notes="\t=HYPERLINK(\"bad\")\nSecond line")
        self.create(company="Other Company", status="Rejected")
        response = self.client.get("/applications/export.csv?status=Applied")
        self.assertEqual(response.status_code, 200)
        self.assertIn("attachment", response.headers["Content-Disposition"])
        rows = list(csv.reader(StringIO(response.data.decode("utf-8-sig"))))
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[1][0], 'தமிழ், "Systems"')
        self.assertEqual(rows[1][1], "'=1+1")
        self.assertTrue(rows[1][-1].startswith("'="))
        for value in ["=1", " +1", "-1", "@sum", "\ttext", "\rtext", "\ntext"]:
            self.assertTrue(tracker.csv_cell(value).startswith("'"))

    def test_export_includes_matches_beyond_the_first_page(self):
        self.login()
        for index in range(13):
            self.create(company=f"Export {index}")
        rows = list(csv.reader(StringIO(self.client.get("/applications/export.csv").data.decode("utf-8-sig"))))
        self.assertEqual(len(rows), 14)

    def test_sample_data_only_on_empty_tracker_and_scoped_to_user(self):
        self.login()
        self.assertEqual(self.post("/sample-data").status_code, 303)
        self.assertEqual(len(self.query("SELECT * FROM applications")), 5)
        self.assertEqual(self.post("/sample-data").status_code, 409)
        dashboard = self.client.get("/dashboard")
        self.assertEqual(dashboard.status_code, 200)
        self.assertIn(b"Orbit Studio", dashboard.data)
        self.assertIn(b"Overdue", dashboard.data)
        self.assertIn(b"Sample", dashboard.data)
        self.assertNotIn(b"Try sample applications", dashboard.data)
        other = self.login("empty@example.com", self.app.test_client())
        self.assertIn(b"Try sample applications", other.get("/dashboard").data)
        self.assertNotIn(b"Orbit Studio", other.get("/dashboard").data)

    def test_transaction_rolls_back_if_history_write_fails(self):
        self.login()
        with patch.object(tracker, "event", side_effect=RuntimeError("Simulated history failure")):
            with self.assertRaises(RuntimeError):
                self.post("/applications/new", self.values())
        self.assertEqual(self.query("SELECT * FROM applications"), [])
        application_id = self.create()
        with patch.object(tracker, "event", side_effect=RuntimeError("Simulated history failure")):
            with self.assertRaises(RuntimeError):
                self.post(f"/applications/{application_id}/edit", self.values(company="Failed Edit", version="1"))
        self.assertEqual(self.query("SELECT * FROM applications")[0]["company"], "Example Systems")
        self.assertEqual(self.query("SELECT * FROM applications")[0]["version"], 1)

    def test_html_escaping_and_sql_parameters(self):
        self.login()
        application_id = self.create(company="<script>alert(1)</script>", notes="Robert'); DROP TABLE users;--")
        response = self.client.get(f"/applications/{application_id}")
        self.assertNotIn(b"<script>alert(1)</script>", response.data)
        self.assertIn(b"&lt;script&gt;", response.data)
        self.assertEqual(len(self.query("SELECT * FROM users")), 1)
        self.assertIn("DROP TABLE", self.query("SELECT * FROM applications")[0]["notes"])
        self.assertIn("script-src 'self'", response.headers["Content-Security-Policy"])
        self.assertEqual(response.headers["Cache-Control"], "no-store")

    def test_data_persists_when_application_is_restarted(self):
        self.login()
        application_id = self.create(company="Persistent Company")
        restarted = tracker.create_app(self.config).test_client()
        self.assertEqual(self.post("/login", {"email": "student@example.com", "password": "Good-password-12"}, restarted).status_code, 303)
        self.assertIn(b"Persistent Company", restarted.get(f"/applications/{application_id}").data)


if __name__ == "__main__":
    unittest.main()
