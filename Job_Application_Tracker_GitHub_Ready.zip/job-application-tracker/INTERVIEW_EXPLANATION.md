# JobTrack — Interview Explanation

## Short English introduction

“My project is a Job Application Tracker built with Python, Flask, SQLite, HTML, CSS, and JavaScript. It helps users record companies and job roles, update application stages, and manage interview and follow-up dates. Each user has a separate dashboard with status counts, search, filters, history, and CSV export.”

Use this explanation after running the app and understanding its implementation. Describe your own contributions accurately; the supplied source was generated with AI assistance.

## Tanglish explanation

“Indha project-la students/job seekers apply panna company details-a save pannalam. Applied, Screening, Interview, Offer, Rejected madhiri status-a update pannalam. Interview date, follow-up date, notes ellam manage pannalam. Dashboard-la progress theriyum. Python Flask backend-um SQLite database-um use pannirukken.”

## Common questions

**Why did you choose this project?**

Job seekers often manage multiple applications in different places. This project brings those records into one workspace and makes the next step visible.

**Why Flask?**

Flask supports routes, templates, sessions, and request handling with a small setup. It fits the scope of this local academic application.

**Why SQLite?**

SQLite stores records in a local file and needs no separate server. It makes the project easy to run on a laptop.

**How do you separate users' data?**

Each application stores a `user_id`. Queries and mutations check that it matches the signed-in user's ID. Other users cannot view, edit, delete, or export that application.

**How are passwords stored?**

Werkzeug generates password hashes. Login checks the submitted password against the stored hash; plaintext passwords are not stored.

**How do you prevent accidental overwrites?**

Every application has a version number. An edit/status/delete request must match the current version. If another tab saved a newer version, the server returns a conflict and asks the user to reload.

**What happens if a database operation fails?**

Application changes and history writes use a transaction. If one fails, the entire change is rolled back.

**Does the app send interview reminders?**

It shows interview and follow-up dates on the dashboard. Email/SMS and background reminders are not implemented.

**Does the project use AI/ML?**

No. This is a full-stack application focused on data management, validation, account access, reporting, and interface design.

**What could you add next?**

Multiple interview rounds, a calendar view, document attachments, and opt-in notifications.
