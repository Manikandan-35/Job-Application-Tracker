# JobTrack — Job Application Tracker

A complete academic full-stack project for students and job seekers. Keep company details, job roles, application stages, interviews, follow-up dates, links, and notes in one personal workspace.

**Stack:** Python 3.10+, Flask, SQLite, HTML, CSS, and JavaScript. No separate database server or API key is required.

## Run on Windows

Install Python 3.10 or newer. Extract `Job_Application_Tracker_GitHub_Ready.zip`, open the `job-application-tracker` folder in VS Code, then open its terminal:

```powershell
py -3 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe app.py
```

Open **http://127.0.0.1:5001** in Chrome. Create your own account, sign in, and add an application. On an empty dashboard, **Try sample applications** adds five clearly marked fictional examples. There are no default accounts or passwords. The database is created automatically.

Press `Ctrl+C` in the terminal to stop the server. Start it again with the final command; saved applications remain in the local database.

## Run on macOS / Linux

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python app.py
```

If port 5001 is occupied, use `python app.py --port 5002` with your virtual environment's Python executable and open `http://127.0.0.1:5002`.

## Features

| Feature | What it does |
| --- | --- |
| Accounts | Register, sign in, and sign out; each account has its own applications. |
| Application management | Add, view, edit, and delete company, role, location, job type, dates, posting link, and notes. |
| Pipeline | Track Applied, Screening, Interview, Offer, Rejected, and Withdrawn stages. |
| Overview | Show total applications, active applications, upcoming interviews, offers, and status distribution. |
| Next steps | Show scheduled interviews and follow-up dates, including overdue follow-ups. |
| Search and filters | Search company/role/location; filter by stage and job type; paginate results. |
| History | Record creation, edits, and status changes. |
| CSV export | Download all applications matching the current filters, including matches beyond the visible page. |
| Sample workspace | Load five fictional records into an empty tracker to explore the app. |

Interview times use **Indian Standard Time (Asia/Kolkata)**. The application date cannot be in the future. Interview and follow-up dates cannot precede the application date. Interview and follow-up lists include active applications; closed stages are excluded.

Dates are shown while you use the dashboard. There are no background reminders or email/SMS notifications. Applications are entered manually; this project does not automatically apply to companies or collect live vacancies.

## Project details and explanation

- [PROJECT_DETAILS.md](PROJECT_DETAILS.md): problem statement, objectives, modules, architecture, database, and future scope.
- [START_HERE_TAMIL.md](START_HERE_TAMIL.md): beginner Tanglish setup and GitHub upload instructions.
- [INTERVIEW_EXPLANATION.md](INTERVIEW_EXPLANATION.md): short English/Tanglish explanation and common interview questions.

## Folder guide

| File / folder | Purpose |
| --- | --- |
| `app.py` | Flask routes, validation, account sessions, SQLite access, and business logic. |
| `schema.sql` | Users, applications, application history, constraints, and indexes. |
| `templates/` | HTML pages rendered with Jinja. |
| `static/` | Responsive CSS, delete confirmation JavaScript, and icon. |
| `tests/test_app.py` | Behavioral integration tests using temporary databases. |
| `docs/TEST_RESULTS.md` | Test coverage and verification limits. |
| `requirements.txt` | Runtime dependencies. |

Runtime data lives under `instance/`, which is excluded by `.gitignore`. Do not upload your virtual environment, local database, session key, or personal application records.

## Tests

```powershell
.venv\Scripts\python.exe -m unittest discover -s tests -v
```

The tests cover the complete application journey, account isolation, session rotation, CSRF, server validation, stale-tab conflicts, transaction rollback, history cleanup, filtered CSV export, pagination, sample data, escaping, and persistence after restart. All 14 integration tests passed. The attempted automated browser run was blocked by the execution environment, so visual and mobile-browser verification is pending. Details are recorded in `docs/TEST_RESULTS.md`.

## Upload to a new GitHub repository

Suggested repository name: **job-application-tracker**

Suggested description: **A Flask and SQLite web app to track job applications, interviews, follow-ups, and status history.**

1. Create a new GitHub repository for this project.
2. Extract the ZIP and open `job-application-tracker` on your laptop/PC.
3. In the new repository, select **Add file → Upload files** and drag the folder's contents into the upload area, including `templates`, `static`, `tests`, and `docs`.
4. Keep `README.md` at the repository root. Enter `Add JobTrack application tracker` as the commit message and commit the files.
5. Confirm that the Code page shows `app.py` and the folders. A ZIP alone keeps the code inside the archive; uploading extracted files makes it directly browsable.

## Implementation notes

Passwords use Werkzeug password hashes. POST forms use session-backed CSRF tokens. SQL values are parameterized, and all application access is scoped to the signed-in user. Mutations and history entries use transactions. Version numbers reject stale-tab edits and deletion. CSV exports prefix formula-like cells with an apostrophe for spreadsheet use.

The bundled server is a local development/demo server. Public hosting requires a production WSGI server and HTTPS. `SECRET_KEY` sets the session key; otherwise a local key is generated. `DATABASE_PATH` can select another SQLite file. `COOKIE_SECURE=1` is for HTTPS hosting.

This is a newly generated project with AI assistance. Run it, review the code, and understand it before presenting it as your work. It does not represent internship experience or measured hiring results.

## Primary documentation

- [Flask tutorial](https://flask.palletsprojects.com/en/stable/tutorial/)
- [Python sqlite3](https://docs.python.org/3/library/sqlite3.html)
- [Python CSV](https://docs.python.org/3/library/csv.html)
- [GitHub: adding files](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository)
